# eBay Clone 🛒

مشروع واجهة مستخدم (Frontend) يحاكي شكل وتصميم موقع eBay باستخدام HTML وCSS وTailwindCSS.

## 💻 التقنيات المستخدمة
- HTML
- CSS
- [Tailwind CSS](https://tailwindcss.com/) (من CDN)

## 📁 محتوى المشروع
- صفحة رئيسية (index.html)
- صفحة تسجيل الدخول
- صفحات إضافية بها منتجات وصور
- تصميم متجاوب إلى حد ما مع استخدام Flexbox و Tailwind

## 📸 لقطات من المشروع
![screenshot](./images/Screenshot%202025-02-21%20022917.png)

## 🚀 تجربة المشروع
بعد رفعه على GitHub Pages، ضع هنا الرابط:

```text
https://your-username.github.io/project-folder/

